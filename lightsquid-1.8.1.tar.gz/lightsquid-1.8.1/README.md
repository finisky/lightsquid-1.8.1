# lightsquid-1.8.1
Forked from http://lightsquid.sourceforge.net/ lightsquid v1.8

Refer to: [Lightsquid Stop Working in 2021](https://finisky.github.io/2021/01/03/lightsquidhardcodeyear.en)

Fix a hardcoded year `2020` bug.
